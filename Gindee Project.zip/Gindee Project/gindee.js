/** Member: 6388052 Runchana, 6388053 Chayanis, 6388057 Phakrada, 6388106 Nantanat
    Section: 3
    Group: 5 */

// Main web application for GinDee, which includes all web services 
// const fetch = require ('cross-fetch')
const express = require('express')
const path = require('path') // Path reference
const bodyParser = require('body-parser')
const dotenv = require('dotenv')
dotenv.config() // Loads .env file 
const PORT = process.env.PORT || 4305 

const database = require('./sec3_gr5_ws_src/database/database') // Connect to database 
const cors = require('cors') // Allow all routes to be Cross-Origin Resource Sharing
const router = require('./sec3_gr5_ws_src/routes/gindeeRoute') // gindeeRoute in routes folder 
const app = express() // Object
const gindeeService = require('./sec3_gr5_ws_src/gindeeService') // Access functions from gindeeService from current directory 

const jwt = require("jsonwebtoken")
const authorize = require("./sec3_gr5_ws_src/middlewares/auth");
const alert = require('alert') // For alerting messages 

app.use(router)
app.use(cors())
app.use(bodyParser.urlencoded({ extended: false}))
app.use(bodyParser.json())

var role = null 
var user_id = null
var email = null 

/******* Normal user *******/
/** Show all products that are listed in GinDee website. */
// Service URL: http://localhost:4305/user/search
app.get('/user/search', (req, res) => {
    gindeeService.searchAll(req, res)
})

// Service URL: http://localhost:4305/user/search/salmon
// Service URL: http://localhost:4305/user/search/chicken
app.get('/user/search/:name', (req, res) => {
    gindeeService.search_product(req, res, 'product') 
})

/** Search a specific product in a specific category.*/
// Service URL: http://localhost:4305/user/search/category/food 
// Service URL: http://localhost:4305/user/search/category/Beverages
app.get('/user/search/category/:name', (req, res) => {
    gindeeService.search_product(req, res, 'category')
})

/** Search a specific product in a specific category.*/
// Service URL: http://localhost:4305/user/search/beverages/milk 
// Service URL: http://localhost:4305/user/search/household/pink
 app.get('/user/search/:category/:name', (req, res) => {
    gindeeService.search_product(req, res, 'category/product')
})


/******* Administrator *******/
// search, view, insert, update and delete products in the system
// search, view, insert, update and delete users in the system

// Testing Insert product
// method: POST
// URL: http://localhost:4305/category/admin/insertproduct
// body: raw JSON
// {
//     "product": 
//     {
//     "product_id": 15204365,
//     "product_name": "Spring Home Roti Paratha Plain 325G.",
//     "product_detail": null,
//     "price": 75,
//     "stock_no": 110,
//     "categories": "Bread&Bakery"
//     }
// }     

// {
//     "product": 
//     {
//     "product_id": 77244861,
//     "product_name": "Doi Kham Tomato Juice 200ML.",
//     "product_detail": "Doi Kham Tomato Juice Low Sodium Formula 200ML. Pack 4", 
//     "price": 68,
//     "stock_no": 210, 
//     "categories": "Beverages"
//     }
// }          
app.post('/category/admin/insertproduct', (req, res) => {
    gindeeService.insertProduct(req, res)
})

// Testing Update product
// method: PUT
// URL: http://localhost:4305/category/admin/updateproduct
// body: raw JSON
// {
//   "product": {
//       "product_id": 15204365,
//       "price": 50
//   }
// }

// {
//   "product": {
//       "product_id": 77244861,
//       "price": 65
//   }
// }
app.put('/category/admin/updateproduct', (req, res) => {
    gindeeService.updateProduct(req, res)
})

// Testing Delete product
// method: DELETE
// URL: http://localhost:4305/category/admin/deleteproduct
// body: raw JSON
// {
//     "product": 
//     {
//         "product_id": 15204365
//     }
// }

// {
//     "product": 
//     {
//         "product_id": 77244861
//     }
// }
app.delete('/category/admin/deleteproduct', (req, res) => {
    gindeeService.deleteProduct(req, res)
})


/** Authentication for all user types, which are normal users and administrators. 
 * This web service will be called when the users login to the web application*/
// Testing Login User 
// method: POST 
// URL: http://localhost:4305/login/user
// body: raw JSON
// {
//     "Username": "johnsonsv",
//     "Password": "John8812"
// }

// {
//     "Username": "johnsonsv",
//     "Password": "falsePassword"
// }
app.post('/login/user', (req, res) => {
    var username = req.body.Username
    var password = req.body.Password

    // verify password
    if(username && password){
        database.query('SELECT user_id, user_role, email FROM login WHERE username = ? AND psw = ?', [username, password], (error, results, fields) => {
            if(error) throw error
            if(results.length > 0){ // The user is found 
                role = results[0].user_role
                user_id = results[0].user_id
                email = results[0].email
                // let jwtToken = jwt.sign({
                //     username: username,
                //     psw: password
                // }, process.env.SECRET, {
                //     expiresIn: "3h"
                // });
                console.log(`Successfully login! The role of this user is '${role}'.`)
                alert(`Successfully login! The role of this user is '${role}'.`)
                return res.redirect('/home')
            }
            else{
                console.log('NOT SUCCESS')
                return res.status(400).send({error: true, message: 'Sorry, you are not allowed to login. Please check your password and username again.'})
            }
        }) 
    }
    
})

// Testing Retrieve all users, method: GET
// URL: http://localhost:4305/login/admin/getuser
app.get('/login/admin/getuser', (req, res) => {
    gindeeService.searchAllUser(req, res)
})

// Testing Search for a specific user with first name, method: GET
// URL: http://localhost:4305/login/admin/getuser/Johnson
// URL: http://localhost:4305/login/admin/getuser/Patty
app.get('/login/admin/getuser/:fname', (req, res) => {
    gindeeService.search_user(req, res) 
})

// Testing Search for a specific user with first name and last name, method: GET
// URL: http://localhost:4305/login/admin/getuser/Johnson/Smith
// URL: http://localhost:4305/login/admin/getuser/Ramida/Yanikarn
app.get('/login/admin/getuser/:fname/:lname', (req, res) => {
    gindeeService.search_user(req, res)
})


// Testing Insert user 
// method: POST
// URL: http://localhost:4305/login/admin/insertuser
// body: raw JSON
// {
//  "users": {
//      "fname": "Colson",
//      "middle_name": "Blade",
//      "lname": "Baker",
//      "DOB": "1990-04-22 18:40:21",
//      "phone_num": "088-679-8443",
//      "email": "colson.kelly@outlook.com",
//      "user_id": 88111807
//  }
// }

// {
//  "users": {
//      "fname": "Katherine",
//      "middle_name": null,
//      "lname": "Welling",
//      "DOB": "1995-10-03 07:43:12",
//      "phone_num": "081-418-0587",
//      "email": "kateyyoh@gmail.com",
//      "user_id": 95369459
//  }
// }
app.post('/login/admin/insertuser', (req, res) => {
    gindeeService.insertUser(req, res)})

// Testing Update user
// method: PUT
// URL: http://localhost:4305/login/admin/updateuser
// body: raw JSON
// {
//  "users": {
//      "user_id": 88111807,
//      "phone_num": "088-679-8000"
//  }
// }

// {
//  "users": {
//      "user_id": 95369459,
//      "phone_num": "088-679-8000"
//  }
// }
app.put('/login/admin/updateuser', (req, res) => {
    gindeeService.updateUser(req, res)})

// Testing Delete user
// method: DELETE
// URL: http://localhost:4305/login/admin/deleteuser
// body: raw JSON
// {
//  "users": {
//      "user_id": 88111807
//  }
// }

// {
//  "users": {
//      "user_id": 95369459
//  }
// }
app.delete('/login/admin/deleteuser', (req, res) => {
    gindeeService.deleteUser(req, res)})
    
// 404 Page (Keep this as the last route)
app.get('*', (req, res) => {
    res.sendFile((path.join(__dirname + '/view/404.html')))
})

app.listen(PORT, console.log(`Server started on port ${PORT}`))

