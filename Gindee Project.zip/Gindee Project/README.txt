-- Setting MYSQL Server 
1. Use MySQL Workbench to access the MySQL server for managing the relational database
2. In MySQL Workbench, run the sec3_gr5_database.sql file.
3. Go to “Server” > “Users and Privileges”
4. Click “Add Account” 
5. In Login, Set Login Name = “root”, Password = “Runchana45”, Limit to Hosts Matching = “Localhost”   
6. Set the schema privilege, Click Add Entry > select “GinDee”, Allow SQL operations (SELECT, INSERT, UPDATE, DELETE).

-- Run main application, gindee.js, to access all services and API. 
1. Type $ cd sec3_gr5_src to access the main directory.
2. Type $ npm init to install node_modules
3. In package.json, set the scripts to be started and reload automatically by using 'nodemon gindee.js'. 
4. Open your command line or terminal and install the following lists. 
        $ npm install alert
        $ npm install bcrypt
        $ npm install cors
        $ npm install cross-fetch
        $ npm install dotenv
        $ npm install express
        $ npm install jsonwebtoken
        $ npm install mysql2
        $ npm install nodemon --save 
        $ npm install path
5. Type $ npm start to run the server 

ครบ มีแค่นี้แหละที่กูทำใหม่ โอเค้

หลังจากนี้เหลือที่ต้องแก้คือ search bar ทั้งหมดในทุกหน้า ** ยกเว้นหน้า Search ** แล้วก็ ปัญหาเมื่อคืนใน userrequest.js