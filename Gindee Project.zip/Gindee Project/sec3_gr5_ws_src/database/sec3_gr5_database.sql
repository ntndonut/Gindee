-- Member: 6388052 Runchana, 6388053 Chayanis, 6388057 Phakrada, 6388106 Nantanat
-- Section: 3
-- Group: 5

drop database if exists GinDee;
create database if not exists GinDee;
use GinDee;

-- product table
create table product(
	product_id		char(8)			primary key,  -- product_id is a primary key
    product_name	varchar(140) 	not null, 
    product_detail	text, 			-- product_detail is nullable
	price			int				not null,
    stock_no	 	int				not null,
    categories		varchar(50)		not null,
    constraint chk_categories check (categories	 in ("Food", "Beverages", "Bread&Bakery", "Household", "Health&BeautyCare"))
);

-- Dumping data for table product
insert into product values
(15204367,	"Ai ichi Salmon Fried Rice 225G.",	"Ai ichi Salmon Fried Rice is delicious frozen food which serves  a good taste of ready meal. Being source of omega3 which helps promote brain health, build healthy skin.", 69.00,	299, "Food"),
(48755527,	"Dalee Smoked Duck Breast 200G.", "Tender Smoked Duck Breast, rich in protein and vitamin B.  We select only the finest duck breasts to serve our customers.", 139.00,	250, "Food"),
(93552718,	"Mmilk Lactose Free Cocoa Strawberry Flavour 430 ML.",	"mMILK Pasteurized Lactose Free Milk is delicious milk and a great source of protein and calcium which helps promote body growth, build healthy bone, teeth and muscle.",	54.00,	158, "Beverages"),
(73217258,	"mMilk Pasteurized Lowfat Milk 430ML.",	"mMILK Pasteurized Milk is delicious milk and a great source of protein and calcium which helps promote body growth, build healthy bone, teeth and muscle.", 36.00,	195, "Beverages"),
(77609361,	"Mmilk Lactose Free Sakura Flavour 430ML.",	"mMILK Pasteurized Lactose Free Milk is delicious milk and a great source of protein and calcium which helps promote body growth, build healthy bone, teeth and muscle.",	50.00,	198, "Beverages"),
(99907667,	"Penny The Chef Black Beer & Krachai Cake 361G.", NULL, 385.00,	20,	"Beverages"),
(59589734,	"GinDee Bakery Artisan Cereal Sourdough Baguette 270G.", "Multi grain-cereal French bread. A unique flavour from the sourdough starter Rich in Protein, Fiber, Vitamin, mineral, and provided complex carbohydrate that help you feel satiated. A unique foot long. Firm but soft and tender inside texture.",	129.00,	25,	"Bread&Bakery"),
(98454123,	"Pao Gel Capsule Fresh Floral Scent 360G. Pack 18",	"Deep cleanse with 4 times concentration helps remove tough stain efficiently.", 199.00,	199, "Household"),
(43097569,	"Breeze Clean And Fresh Laundry Detergent Pods 18 Capsule. 270G.",	"New Breeze permeates the laundry. Special formula 3in1, tiny but beautiful, fragrant from the rose field with 3 features. There are 18 compartments in 1 box, good water absorption.", 169.00,	201,"Household"),
(13549935,	"Taffix Personal Virus Protection 1G.",	"Taffix™ is used to block viruses within the nasal cavity, viruses that could penetrate the respiratory system and cause infection.",	699.00,	155, "Health&BeautyCare"),
(98209529,	"3D Mask Daily Size M 10PCS",	NULL,	73.00,	80,	"Health&BeautyCare"),
(87665193,	"Garnier Light Eye Rollon Cream 15ML.",	NULL,	209.00,	69,	"Health&BeautyCare"),
(51493014,	"FARMER'S BREAD Country Nut Bread",	NULL,	140.00,	45,	"Bread&Bakery"),
(53466052,	"Allowrie Salted Butter 227G.",	"Salted Pure butter 227g, Raw materials imported from country and not contain vegetable fat and preservatives.Butter oil (milk fat) 80%, Milk Powder 2%, Salt 2%Spread butter for bread and as a food ingredient.Keep refrigerated at 0-8 C",	114.00,	73,	"Bread&Bakery"),
(10471217,	"American Style Shoestring 750G.",	 "Shoestring French Fries Grown with care for the environment by farmers who share our values. Our fundamental belief is that few things in life are more important than the food you buy. Good quality is essential.", 	95.00,	350, "Food"),
(98836624,	"First Pride Plant Based Larb Bites 170G.",	"Ingredient: Vegetable Proteins (Soy, Wheat) 43%, Wheat flour 20%, Vegetable Fibers 8%, Vegetable Oil 8%, Water 5%, Starch (Wheat, Tapioca, Corn) 4%, Salt 2%, Sugar 1%, Roasted Rice 1%, Spice & Herb, Natural Flavouring, Spice Extract, Garlic Powder, Onion Powder, Food Additives, Natural Colour  Allergen", 	99.00,	142, "Food"),
(79100151,	"Downy Concentrated Fabric Softener Passion Bts 500ML.",	 "Spark glamour in you every day. Perfume Premium Premium Keep the fabric soft. Prevent unpleasant odor Easy ironing Fragrant for 3 weeks Compared to not using fabric softening products", 	79.00,	300,	"Household"),
(35709257,	"3 Ants Shanjia Ant-Killer 4G.",	"Sprinkle Shanjia brand 3 ants where there are ants or paths that ants walk through, when the ants touch prey, they will carry their prey back to the nest for be food and make it possible to get rid of other ants. After 24 hours, sweep Shanjia brand 3 ants from the crowded area or pets may touch Do not sprinkle it near food or in food storage. Do not sprinkle it where children can reach and pets can lick it. Features The product is a type of bait for eliminating ants. Can get rid of all ants in the nest without wasting time looking for ant nests Convenient packaging, easy to use, not scatter, no disturbing smell", 32.00, 193, "Household"),
(19945954,	"Ars Jet Gold 3 Lavender 600ML.", "property 1. Effective formula to get rid of mosquitoes, ants, cockroaches, works quickly. 2. Effective against cockroaches continuously for 4 weeks. 3. It has a smell of lavender. how to use 1. Spray in the desired area.",	95.00,	287, "Household"),
(21219046,	"Tipco Mixed Fruit Juice with Cranberry 1000ML.",	 "TIPCO 100% Mixed Fruit Juice Cranberry Formula 1000 ml. is made of premium grade cranberries and various fruits from high-quality plantations. It is a refreshing drink and is rich in health benefits.", 	72.25,	260, "Beverages"),
(19187421,	"Peppina Gelo Margherita Pizza 345G.",	"Margherita Pizza by Peppina Gelo The classic pizza made using slow fermented pizza dough and topped with Peppina’s tomato sauce, Mozzarella and basil. All Peppina Gelo Pizzas are hand formed and baked in a stone oven. ",	299.00,	10,	"Food"),
(18168068,	"Kitchen Joy Chicken Middle Wing Orleans 500G.",	"KJ Orlean Middle Wing comes in a large piece, with tender texture and deliciousness, especially from Orlean seasoning. It gives a bit of spiciness and stong flavour, by having it with hot steamed rice make them become a perfect combination.",	189.00,	18,	"Food"),
(83884298,	"Penny The Chef Mini Almond Croissant 77G.",	NULL,	95.00,	18,	"Bread&Bakery"),
(63645969,	"CUBIC Whole Wheat Cranberry Bun 47G.",	NULL,	35.00,	42,	"Bread&Bakery"),
(58564604,	"Dok Bua ku Herbal Mouthwash Clove 250ML.",	"Freshen your breath.Increase your confidence thoughout the day. With the mixture of natural herbs, Clove,Sage,Licorice Extract,Clove Herbal Mouthwash Protects the enamel and reduces the accumulation of plaque,and stains. Prevent bad breath and protect the toot enamel. Clove Herbak Mouthwash is sooting,cool and refreshing.",	80.00,	39,	"Health&BeautyCare"),
(51499223,	"Citra Herbal Restoring Bright UV Lotion 380ML.",	"Citra Restoring Bright UV Because we believe that the body skin is as important as the face. Citra therefore selects 100% natural skin essence to combine in body lotion. Super Collagen with 2 times more collagen and Pure Vitamin C For bright aura body skin, look radiant, juicy, bouncing like facial skin. ",	119.00,	22,	"Health&BeautyCare"),
(69056868,	"Dettol Hygiene 750ML.",	"“Dettol Hygiene” is effective in disinfection. Help kill germs 99.9%. When mixed with water, a white opaque solution will occur which represents the disifectant efficiency to kill germs on clothes or other surfaces/equipments",	439.00,	81,	"Household"),
(10812744,	"Magiclean Floor Pink 5200ML.",	"Magiclean Floor cleaner. Just 1 wipe, can remove dust, sticky stains and oily stains on floor, comfortable on feet while walking, not sticky on floor, quick dry and not leave footprints. Long-lasting fragrance with Lily bouquet fragrance.",	197.00,	27,	"Household"),
(95835909,	"mMilk Green Pasteurized Lactose Free Milk 430ML.",	"High quality milk which take good care cows by feeding high chlorophyll from green plant or call “Fresh Milk from Grass – Fed Cows High quality milk which take good care cows by feeding high chlorophyll from green plant.",	66.00,	157	,"Beverages"),
(82812960,	"mMilk Pasteurized Lactose Free Milk Box 430ML.",	"mMILK Pasteurized Lactose Free Milk is delicious milk and a great source of protein and calcium which helps promote body growth, build healthy bone, teeth and muscle. ",	50.00,	197,	"Beverages");

-- user table
create table users(
	fname			varchar(50) 		not null,  
	middle_name		varchar(50),  		-- middle_name is nullable
	lname			varchar(50)  		not null,
    DOB				datetime			not null,
    phone_num		varchar(12)			not null,
    email			varchar(255)		unique,
    user_id			varchar(8)			primary key, -- user_id is a primary key
  CONSTRAINT chk_DOB check ((year((sysdate())-year(DOB)))>=18)
);

-- Dumping data for table user
insert into users values
("Johnson", NULL, "Smith", "1997-02-09 13:23:44", "088-626-6889",  "johnson.sm@hotmail.com", 77985459),
("Adisorn",	NULL, "Srisuk", "1997-10-12 15:45:21", "095-558-4420", "addyyy@gmail.com", 49257012),
("Rolex", "Mar", "Mackenvy", "1994-01-28 11:12:01", "065-554-1799", "rolexmack@gmail.com", 25263497),
("Peter", NULL, "White", "1991-04-23 14:56:59", "095-555-3243", "whitewhitept@gmail.com", 71163258),
("Arthit", NULL, "Jainukul", "1994-11-17 10:27:49", "085-522-5830", "thit.jainukul@gmail.com",	31885762),
("Malee", NULL,	"Yingyong", "1998-06-10 20:01:39", "065-558-3504",	"maleeyyog@gmail.com", 87814545),
("Robert", "Rob", "Wood", "2000-08-30 09:50:21", "081-432-7891", "woodyrobert@gmail.com", 39084597),
("Chan", "Drake", "Foster", "2000-09-04 21:40:38", "095-622-7654",	"drake.fosterr@gmail.com",	97009203),
("Michael",	NULL, "Clark", "1998-12-12 07:30:02", "087-587-1235",	"michaelxclark@gmail.com",	69108119),
("William",	NULL, "Hill", "2000-02-25 19:09:13","065-462-6548",	"hillhillhappy@gmail.com",	89117944),
("Johnny", NULL, "Orlando","2003-01-24 21:20:48","065-552-5448",	"john.orlan@gmail.com",	75621439),
("Patty", "Roren", "Morgan", "1995-10-18 14:59:08", "095-556-4441", "ppat_ty@gmail.com", 72241601),
("Mark", "Yien", "Tuan", "1993-09-04 17:07:17","093-467-1124",	"m.93mt@gmail.com",	81278931),
("Akira", "Thyme", "Paramaanantra", "2000-07-16 12:27:21","084-974-3649",	"thymeeeaki@gmail.com",	32641352),
("Phubadin", NULL, "kaisorn", "2001-08-13 05:18:24",	"094-585-9410",	"Dinnbadin@gmail.com",	23853262),
("Sarach",	NULL, "Yooyen", "1995-11-04 17:04:58",	"082-649-7125",	"tangseryy@gmail.com",	60975170),
("Mira", NULL, "Asavarattanakul", "1999-02-23 04:21:22","063-654-4368",	"miraminely@gmail.com",	90483892),
("Renita", NULL, "Wirairoth", "1992-05-24 10:00:43","081-254-6134",	"Rennitarain@gmail.com", 85126153),
("Tia",	NULL, "Sofia", "2001-10-05 23:01:18","063-659-1296",	"dontmakemetia@gmail.com",	59848225),
("Ramida", NULL, "Yanikarn", "1995-09-27 03:48:17", "092-584-6543",	"janeeeyeh@gmail.com",	29821931),
("Suttiwat", NULL, "Sawat", "1991-09-28 14:49:25","095-596-5025",	"suttiwat_sawat11@hotmail.co.th",	22049735),
("Satayu", "Tardpong", "Klinpraneet", "2002-03-17 12:05:40", "085-556-8382", "klin_sata@hotmail.com",	60737889),
("Kaew", NULL, "Boonmee", "2002-07-14 08:28:04","098-257-5488", "kaewboon19@hotmail.com", 41857282),
("Khunying", "Alexa", "Rardchawat", "1997-09-28 13:48:20","087-598-2354",	"ying.alex77@gmail.com",	57911383),
("Pitsamai", NULL, "Kurusatienkit", "1992-04-18 02:43:05","083-215-9555",	"pitsamai.kt@hotmail.com",	41981072),
("Aawut", NULL, "Sepsook", "1999-11-21 04:50:59","099-985-5401",	"awut.sep@gmail.com",	41498445),
("Chatichai", "Chaiya",	"Kwaigno", "1998-12-04 18:40:21","098-244-8555",	"chatichai99happy@hotmail.com",	60390073),
("Tarrin",	NULL, "Tawisuwan", "1995-04-14 18:49:28","084-888-1298",	"tarrin.wan@hotmail.com",	51932354),
("Thanin",	NULL, "Chaipatana", "1996-08-26 20:54:39","086-698-4453",	"thanin.chaipat@gmail.com",	34735878),
("Fangnimit", NULL, "Findee", "2000-07-19 08:42:55","089-732-6159",	"fineveryday777@gmail.com",	12481907); 

-- address table
create table address(
	details			text				not null, 
	province	 	varchar(50)			not null,
    zip_code		char(5)				not null,
    user_id			varchar(8)			not null,
    constraint fk_address_userid foreign key (user_id) references users(user_id),
    primary key(user_id) -- user_id is both a foreign key and primary key.
);

-- Dumping data for table address
insert into address values
("645/16 Gp 5 Soi Phibun Village Sukhaphiban 1 Klong Goom Buengkhum", "Bangkok", "10240", 77985459),
("187/30 Chula Soi 30 Banthadthong Road", "Bangkok", "10330", 49257012),
("606/3 Soi Mangkorn 2 Pom Prab", "Bangkok", "10100", 25263497),
("Phang-nga Road Mueang Phuket ",	"Phuket",	"83000", 71163258),
("71/17 Boromratchachonnanee Road Bangkoknoi",	"Bangkok",	"10700", 31885762),
("307/116 Soi Charansanidvongs 31 Charansanidvong Road Bangkhunsri Bangkok",	"Bangkok",	"10700", 87814545),
("186/29 Gp 6 Wongwaen 340 Bang Khae Nua Bangkhae Bangkok",	"Bangkok",	"10160", 39084597),
("Maneeya Center Building 14 Floor 518/5 Pleonjit Road Lumpini Pathumwan",	"Bangkok",	"10330", 97009203),
("54/29 Gp 6 Talingchan -Suphanburi Sao Thong Hin Bang Yai Nonthaburi",	"Nonthaburi",	"11140", 69108119),
("119 Moo 3 Petchkasem Road Nong Pho", "Ratchaburi", "70120", 89117944),
("427/20 Pracharaj 2 Road",	"Bangkok",	"10800", 75621439),
("487/5 Soi Phetkasem 67, Phetkasem Rd., Phasi Charoen",	"Bangkok",	"10160", 72241601 ),
("369-375 Rama 4 Road Rongmuang",	"Bangkok",	"10330", 81278931),
("199/2 Sukhumvit 93 Bang Jark Phra Khanong",	"Bangkok",	"10250", 32641352),
("2100/33 Soi Taweewanthana Chan Road",	"Bangkok",	"10120", 23853262),
("90/9 Moo 4 Chaengwatana 13 Road Tung Song Hong",	"Bangkok",	"10210", 60975170),
("Sukhumvit Road, Pattaya, Bang Lamung",	"Chonburi",	"20150", 90483892),
("5/11, Chao Fan Tawn Tok Road, Mueang",	"Phuket",	"83100", 85126153),
("1575/6 Phaholyothin Road Samsennai Phayathai",	"Bangkok",	"10400", 59848225),
("54/36-37 Moo5 Rama 2 Road",	"Bangkok",	"10150", 29821931),
("6228230232 Soi Charansanidvongs 84 Charansanidvongs Road",	"Bangkok",	"22422", 22049735),
("30 Gp 6 Phuthamontholsai 4 Kratumlom Sam Phran",	"Bangkok",	"73220", 60737889),
("Jitt Uthai Building, 2563 Ramkhamhaeng Road, Bang Kapi",	"Bangkok",	"10240",41857282),
("Phraek Sa, Muang Samutprakarn, Samutprakarn",	"Samut Prakan",	"10270", 57911383),
("Imperial World, 2539 Lat Phrao Road, Wang Thonglang",	"Bangkok",	"10310",41981072),
("286/53-54 Soi Patana, Surawong Rd., Bangrak",	"Bangkok",	"10500",41498445),
("1/46 Sunthornkosa Khlong Toei Khlong Toei",	"Bangkok",	"10110", 60390073),
("37/39 Soi 39 Ramintra Anusaowaree",	"Bangkok",	"10220", 51932354),
("366 Yawaraj Road Chakrawad Samphanthawong",	"Bangkok",	"10100", 34735878),
("108 Sukhumvit 53 Klongton Nua Watthana",	"Bangkok",	"10110", 12481907);

-- login table
create table login(
	user_id			varchar(8)		not null,
    username		varchar(50) 	primary key,  -- username is a primary key
    psw				varchar(50) 	not null,  -- password
    user_role		varchar(50)		not null,
    login_log	 	timestamp		not null,
    email			varchar(255)	not null,
    constraint chk_role check (user_role in ("Normal user", "Administrator")),
    constraint fk_userid foreign key (user_id) references users(user_id), -- user_id is a foreign key
    constraint fk_email	foreign key (email) references users(email)-- email also is a foreign key
);

-- Dumping data for table login
insert into login values
(77985459,	"johnsonsv",	"John8812",	"Normal user",	"2022-02-05 18:34:11",	"johnson.sm@hotmail.com"),
(49257012,	"addy_99",	"gindeetestacc",	"Administrator",	"2022-02-05 18:35:25",	"addyyy@gmail.com"),
(25263497,	"macmacro",	"Dinosaur00",	"Normal user",	"2022-02-05 18:35:28",	"rolexmack@gmail.com"),
(71163258,	"whitekung",	"ruinmylife21",	"Normal user",	"2022-02-05 18:37:50",	"whitewhitept@gmail.com"),
(31885762,	"sunny_ja",	"Arthitxx2684",	"Normal user",	"2022-02-05 18:38:01",	"thit.jainukul@gmail.com"),
(87814545,	"maleepcy",	"Maaaaal32",	"Normal user",	"2022-02-05 18:38:05",	"maleeyyog@gmail.com"),
(39084597,	"doowbor",	"Cantremember",	"Normal user",	"2022-02-05 18:40:00",	"woodyrobert@gmail.com"),
(97009203,	"fosterchan1405",	"Fn158974",	"Normal user",	"2022-02-05 18:40:32",	"drake.fosterr@gmail.com"),
(69108119,	"michaleishere",	"worktodeadline8987",	"Administrator",	"2022-02-05 18:40:44",	"michaelxclark@gmail.com"),
(89117944,	"liam_hill",	"k01433458",	"Normal user",	"2022-02-05 18:41:02",	"hillhillhappy@gmail.com"),
(75621439,	"johnn__ola",	"Noran21545",	"Normal user",	"2022-02-06 18:42:34",	"john.orlan@gmail.com"),
(72241601,	"ppatygan",	"morGaty582",	"Normal user",	"2022-02-06 18:43:12",	"ppat_ty@gmail.com"),
(81278931,	"mttmneiy",	"mTT93yyb",	"Administrator",	"2022-02-06 18:43:53",	"m.93mt@gmail.com"),
(32641352,	"Thymemybw",	"akhyt2721",	"Administrator",	"2022-02-06 18:44:28",	"thymeeeaki@gmail.com"),
(23853262,	"dinnwinnie",	"poohbahh5110",	"Normal user",	"2022-02-06 18:45:54",	"Dinnbadin@gmail.com"),
(60975170,	"rachrichy",	"cooldown664",	"Normal user",	"2022-02-06 18:47:09",	"tangseryy@gmail.com"),
(90483892,	"mymimister",	"luvasasi87",	"Normal user",	"2022-02-06 18:50:31",	"miraminely@gmail.com"),
(85126153,	"rainnyvevi",	"seasoning245",	"Normal user",	"2022-02-06 18:53:47",	"Rennitarain@gmail.com"),
(59848225,	"crymakee",	"cryalwaysna",	"Normal user",	"2022-02-06 19:17:36",	"dontmakemetia@gmail.com"),
(29821931,	"raminiemic",	"disneyonice89",	"Normal user",	"2022-02-06 19:25:17",	"janeeeyeh@gmail.com"),
(22049735,	"sawatdee_tiwat",	"suttiwat5025",	"Normal user",	 "2020-02-07 19:32:57",	"suttiwat_sawat11@hotmail.co.th"),
(60737889,	"tardpongkpn", 	"kpnlalala82",	"Normal user",	"2020-02-07 19:38:42",	"klin_sata@hotmail.com"),
(41857282,	"kaewwiecute",	"karnkaewxs5",	"Administrator",	"2020-02-07 19:44:22",	"kaewboon19@hotmail.com"),
(57911383,	"khunying_alexa",	"alexamaiying",	"Normal user",	"2020-02-07 19:49:43",	"ying.alex77@gmail.com"),
(41981072,	"chuan_pitsamai",	"pitsamai555",	"Normal user",	"2020-02-07 19:55:38",	"pitsamai.kt@hotmail.com"),
(41498445,	"anuwat_ss",	"sepsookgun",	"Normal user",	"2020-02-07 19:58:47",	"awut.sep@gmail.com"),
(60390073,	"chaiyakrub",	"555maignona",	"Normal user",	"2020-02-07 20:03:32",	"chatichai99happy@hotmail.com"),
(51932354,	"tarrinteh",	"tarrinx2022",	"Normal user",	"2020-02-07 20:10:19",	"tarrin.wan@hotmail.com"),
(34735878,	"chaninchai",	"meechai99",	"Normal user",	"2020-02-07 20:14:54",	"thanin.chaipat@gmail.com"),
(12481907,	"fangfangnimit",	"finfin1234",	"Normal user",	"2020-02-07 20:20:20",	"fineveryday777@gmail.com");

