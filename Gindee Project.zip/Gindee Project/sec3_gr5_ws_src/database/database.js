/* GinDee Service connect to database 
Member: 6388052 Runchana, 6388053 Chayanis, 6388057 Phakrada, 6388106 Nantanat
Section: 3
Group: 5*/

var mysql = require('mysql2') 

// .env file 
const dotenv = require('dotenv')
dotenv.config()
const port = process.env.PORT || 4305

var GinDee = mysql.createConnection({
    host: process.env.host,
    user: process.env.DB_user,
    password: process.env.DB_pass,
    database: process.env.DB_name,
});

GinDee.connect(function(err){ 
    if(err){
        console.log('Cannot connect to the database.')
        console.log(err)
    }
    else{
        console.log(`Connected to the database named: ${process.env.DB_name}`)
    }
}) 

module.exports = GinDee; // Export database 