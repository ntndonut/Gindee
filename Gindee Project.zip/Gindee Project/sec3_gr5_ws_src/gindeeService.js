/** Member: 6388052 Runchana, 6388053 Chayanis, 6388057 Phakrada, 6388106 Nantanat
    Section: 3
    Group: 5 */

const database = require('./database/database') // Connect to database 

/** Function that will be used for searching a specific product in all categories. 
 *  Authorization: Both users and administrators **/ 
exports.search_product = function(req, res, type){
    if(type == 'product'){ // Strict eqaulity
        let product_name = '%' + req.params.name + '%' // LIKE %product_name%
        database.query('SELECT * FROM product WHERE product_name LIKE ?', product_name, function(error, results){
            if(error) throw error;
            let empty = results.length
            if(empty == 0){ // There is no product in the store. 
                return res.status(400).send({ error: true, message: `Sorry, we cannot find ${req.params.name} in our website.` })
            }
            return res.send({ error: false, data: results, message: `${req.params.name} is retrieved.`})
        })
    }
    else if(type == 'category'){ // Search for each category 
        let category_name = '%' + req.params.name + '%'
        database.query('SELECT * FROM product WHERE categories LIKE ?', category_name, (error, results) => {
            if(error) throw error;
            let empty = results.length
            if(empty == 0){ // There is no this category in the store. 
                return res.status(400).send({ error: true, message: `Sorry, we cannot find ${req.params.name} in our website.` })
            }
            return res.send({ error: false, data: results, message: `${req.params.name} is retrieved.`})
        })
    }
    else if(type == 'category/product'){ // Search for a product in a specific category 
        let category_name = '%' + req.params.category + '%' // LIKE %category_name%
        let product_name = '%' + req.params.name + '%' // LIKE %product_name%
        database.query('SELECT * FROM product WHERE product_name LIKE ? AND categories LIKE ?', [product_name, category_name], function(error, results){
            if(error) throw error;
            let empty = results.length
            if(empty == 0){ // There is no product in the store. 
                return res.status(400).send({ error: true, message: `Sorry, we cannot find ${req.params.name} in ${req.params.category}.` })
            }
            return res.send({ error: false, data: results, message: `${req.params.name} in ${req.params.category} is retrieved.`})
        })
    }
}

/** Show all products that are listed in our web application. 
 *  Authorization: Both users and administrators **/
exports.searchAll = function(req, res){
    database.query('SELECT * FROM product', function(error, results){
        if(error){
            return res.status(400).send({ error: true, message: 'Sorry, the content is not available.'})
        }
        return res.send({ error: false, data: results, message: 'All information is retrieved.'})
    })
}

/******* Administrator | PRODUCTS *******/
/** Admin: Insert product 
 *  Method: POST
*/ 
// {
//     "product": 
//      {
//           "product_id": 15204365,
//           "product_name": "Spring Home Roti Paratha Plain 325G.",
//           "product_detail": null,
//           "price": 75.00,
//           "stock_no": 110,
//           "categories": "Bread&Bakery"
//      }
// }
exports.insertProduct = function(req, res){ 
    let product = req.body.product; 
    if(!product){ 
        return res.status(400).send({ error: true, message: 'Sorry, you cannot insert the specific product.'});
    }
    database.query("INSERT INTO product SET ?", [product], (error, results) => {
        if (error) throw error;
        console.log(product)
        return res.send({error: false, data: results.affectedRows, message: 'New product has been created successfully.'});
    }) 
} 
/** Admin: Update products 
 *  Method: PUT
*/
exports.updateProduct = function(req, res){
    let product_id = req.body.product.product_id 
    let product = req.body.product

    if (!product_id || !product) {
        return res.status(400).send({ error: product, message: 'Sorry, you cannot update the product.'})
    } 
    database.query("UPDATE product SET ? WHERE product_id = ?", [product, product_id], function(error, results){
        if (error) throw error
        return res.send({error: false, data: results.affectedRows, message: 'Product has been updated succesfully.'})
    })
}  

/** Admin: Delete products 
 *  Method: DELETE
*/
exports.deleteProduct = function(req, res){
    let product_id = req.body.product.product_id // product table in the database
    if(!product_id){
        return res.status(400).send({error: true,message: 'Please provide a product id.'})        
    }
    database.query('DELETE FROM product WHERE product_id = ?', product_id, function (error,results){
        if(error) throw error
        return res.send({error: false, data: results.affectedRows, message: 'Product has been deleted successfully.'})
    })   
}

/******* Administrator | USERS *******/

exports.searchAllUser = function(req, res){
    database.query('SELECT * FROM users', function(error, results){
        if(error){
            return res.status(400).send({ error: true, message: 'Sorry, the content is not available.'})
        }
        return res.send({ error: false, data: results, message: 'All information is retrieved.'})
    })
}

/** Search for a user by using the first name */
exports.search_user = function(req, res){
    var user_fname =  '%' + req.params.fname + '%'
    var user_lname = null 
    if(req.params.lname != null){ // If the last name is specified 
        user_lname = '%' + req.params.lname + '%' 
        database.query('SELECT * FROM users WHERE fname LIKE ? AND lname LIKE ?', [user_fname, user_lname], function(error, results){
            if(error) throw error;
            let empty = results.length
            if(empty == 0){ // This user does not exist
                return res.status(400).send({ error: true, message: `Sorry, we cannot find the user named ${req.params.fname} ${req.params.lname} in our system.` })
            }
            return res.send({ error: false, data: results, message: `An information about the user named ${req.params.fname} ${req.params.lname} is retrieved.`})
        })
    }
    else{
        database.query('SELECT * FROM users WHERE fname LIKE ?', user_fname, function(error, results){
        if(error) throw error;
        let empty = results.length
        if(empty == 0){ // This user does not exist
            return res.status(400).send({ error: true, message: `Sorry, we cannot find the user named ${req.params.fname} in our system.` })
        }
        return res.send({ error: false, data: results, message: `An information about the user named ${req.params.fname} is retrieved.`})
        })
    }
} 


/** Admin: Insert user
 *  Method: POST
*/
exports.insertUser = function(req, res){
    let user = req.body.users
    console.log(user)
    if(!user){
        return res.status(400).send({error: true, message: 'Sorry, you cannot insert the specific user.'})
    }
    database.query("INSERT INTO users SET ?", user, function(error, results){
        if(error) throw error
        return res.send({error: false, data: results.affectedRows, message: 'New user has been created successfully.'})
    })
}

exports.updateUser = function(req, res){
    let user_id = req.body.users.user_id
    let users = req.body.users
    if (!user_id || !users) { 
        return res.status(400).send({ error: users, message: 'Sorry, you cannot update this user.'})
    } 
    database.query("UPDATE users SET ? WHERE user_id = ?", [users, user_id], (err, results) => {
        if(err){
            return res.status(400).send({ error: true, message: 'Sorry, you cannot update this user.'})
        }
        else{
            return res.send({error: false, data: results.affectedRows, message: 'User has been updated succesfully.'})
        }
        
    })
}  

exports.deleteUser = function(req, res){
    let user_id = req.body.users.user_id
    if (!user_id) {
        return res.status(400).send({ error: true, message: 'Please provide user_id' });
    }
    database.query('DELETE FROM users WHERE user_id = ?', user_id, function (error, results)
    {
        if (error) throw error;
        return res.send({ error: false, data: results.affectedRows, message: 'User has been deleted successfully.' });
    });
}

