/** Member: 6388052 Runchana, 6388053 Chayanis, 6388057 Phakrada, 6388106 Nantanat
    Section: 3
    Group: 5 */

/** Create connections from the interface to the web services for normal users */
// Search and Result pages will be connected to the search and view services

/* result section*/
var productlist = document.querySelector('#productlist'); // Use the template inside javavscript
var productrow = document.querySelector('.productrow');

/* reference to user input and search button */
var searchTyp = document.querySelector('#searchtypes');
var searchButtonRef = document.querySelector('#searchBtn');
var input = document.querySelector('#searchKey');

searchButtonRef.addEventListener('click', (e) => {
    e.preventDefault() // Stop page from reloading
    console.log("click")
    if (searchTyp.value === 'product'){
        // Test case: chicken
        // Test case: salmon 
        // Return some products with a specific product name
        console.log("Return some products with a specific product name")
        fetch('/user/search/'+input.value)
        .then(res => res.json())
        .then(data => { 
            data.data.forEach( (element)=>{
            const product = productlist.content.cloneNode(true).children[0]
            const name = product.querySelector('#productname')
            const category = product.querySelector('#category')
            const details = product.querySelector('#details')
            const price = product.querySelector('#price')
            name.textContent = '🔍 '+ element.product_name +' ✨'
            category.textContent = '[ ' + element.categories + ' ]'
            details.textContent = element.product_detail
            price.textContent = element.price + ' ฿'
            productrow.append(product)   // append every detail to the div .productrow 
            console.log('Retrieved all searched results succesfully!')
        })
    }).catch(error => console.log(error))} 
     else if (searchTyp.value === 'category/product') {
         // Test case: beverages/milk
         // Test case: household/pink
        fetch('/user/search/'+ input.value)
        .then(res => res.json())
        .then(data => {
            data.data.forEach((element) => {
                const product = productlist.content.cloneNode(true).children[0]
                const name = product.querySelector('#productname')
                const category = product.querySelector('#category')
                const details = product.querySelector('#details')
                const price = product.querySelector('#price')

                name.textContent = '🔍 '+ element.product_name +' ✨'
                category.textContent = '[ ' + element.categories + ' ]'
                details.textContent = element.product_detail
                price.textContent = element.price + ' ฿'
                productrow.append(product) // append every detail to the div .productrow 
                console.log('Retrieved all searched results succesfully!')
            })
        }).catch(error => console.log(error))} 
     else if (searchTyp.value === 'category'){
        // Return some products with a specific category
        console.log('Return some products with a specific category')
        fetch('/user/search/category/'+input.value)
        .then(res => res.json())
        .then(data => {
            data.data.forEach((element) => {
                const product = productlist.content.cloneNode(true).children[0]
                const name = product.querySelector('#productname')
                const category = product.querySelector('#category')
                const details = product.querySelector('#details')
                const price = product.querySelector('#price')

                name.textContent = '🔍 '+ element.product_name +' ✨'
                category.textContent = '[ ' + element.categories + ' ]'
                details.textContent = element.product_detail
                price.textContent = element.price + ' ฿'
                productrow.append(product) // append every detail to the div .productrow 
                console.log('Retrieved all searched results succesfully!')
            })
        }).catch(error => console.log(error))} 
     else {
        // No criteria: Return all results with no criteria 
        fetch('/user/search') 
        .then(res => res.json())
        .then(data => {
            let count = 0
            data.data.forEach((element) => {
                count += 1 // Showing the number of product 
                const product = productlist.content.cloneNode(true).children[0]
                const name = product.querySelector('#productname')
                const category = product.querySelector('#category')
                // // const details = product.querySelector('#details')
                const price = product.querySelector('#price')
                name.textContent = count + ') ' + '🔍 '+ element.product_name +' ✨'
                category.textContent = '[ ' + element.categories + ' ]' 
                // details.textContent = element.product_detail
                price.textContent = element.price + ' ฿'
                productrow.append(product)
                console.log('Retrieved all searched results succesfully!')
        })
     })
}})