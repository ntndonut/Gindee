/** Member: 6388052 Runchana, 6388053 Chayanis, 6388057 Phakrada, 6388106 Nantanat
    Section: 3
    Group: 5 */

// gindeeService is used for routing purposes 

const express = require('express');
const path = require('path') // Path reference
const router = express.Router()
router.use(express.json())

// Index route Service URL: http://localhost:4305
router.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../../view/HomePage.html'))
});

router.get('/home', (req, res) => {
    res.sendFile(path.join(__dirname, '../../view/HomePage.html'))
});

router.get('/public/headersection.css', (req, res) => { // Navigation bar with CSS process
    res.sendFile(path.join(__dirname, '../../public/headersection.css'))
})

router.get('/public/login.css', (req, res) => { 
    res.sendFile(path.join(__dirname, '../../public/login.css'))
})

router.get('/public/result.css', (req, res) => { 
    res.sendFile(path.join(__dirname, '../../public/result.css'))
})

/** Login page 
 *  Service URL: http://localhost:4305/login
*/
router.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, '../../view/LoginPage.html'))
});

/** Search page 
 *  Service URL: http://localhost:4305/search
*/
router.get('/search', (req, res) =>{
    res.sendFile(path.join(__dirname, '../../view/Search.html'))
})

/** Registration page 
 *  Service URL: http://localhost:4305/register
*/
router.get('/register', (req, res) => {
    res.sendFile(path.join(__dirname, '../../view/Register.html'))
});

/** About us page 
 *  Service URL: http://localhost:4305/aboutus
*/
router.get('/aboutus', (req, res) => {
    res.sendFile(path.join(__dirname, '../../view/AboutUs.html'))
});

/** Categories page 
 *  Service URL: http://localhost:4305/category
*/
router.get('/category', (req, res) => {
    res.sendFile(path.join(__dirname, '../../view/Categories.html'))
})

/** Inside the main categories page, there are food, beverages, health-beautycare, household, bread-bakery 
 *  Service URL: http://localhost:4305/category/food
 *  http://localhost:4305/category/beverages
 *  http://localhost:4305/category/health-beautycare
 *  http://localhost:4305/category/household
 *  http://localhost:4305/category/bread-bakery
*/
router.get('/category/food', (req, res) =>{
    res.sendFile(path.join(__dirname, '../../view/Food.html'))
})

router.get('/category/beverages', (req, res) =>{
    res.sendFile(path.join(__dirname, '../../view/Beverages.html'))
})

router.get('/category/health-beautycare', (req, res) =>{
    res.sendFile(path.join(__dirname, '../../view/HealthBeautyCare.html'))
})

router.get('/category/household', (req, res) =>{
    res.sendFile(path.join(__dirname, '../../view/Household.html'))
})

router.get('/category/bread-bakery', (req, res) =>{
    res.sendFile(path.join(__dirname, '../../view/BreadBakery.html'))
})

/** Cart page */
router.get('/home/cart', (req, res) =>{
    res.sendFile(path.join(__dirname, '../../view/Cart.html'))
})

/** Checkout page */
router.get('/home/checkout', (req, res) =>{
    res.sendFile(path.join(__dirname, '../../view/Checkout.html'))
})

router.get('/userrequest.js', (req, res) => {
    res.sendFile((path.join(__dirname, '../userrequest.js')))
})

module.exports = router; // Export router for using in the main application; gindee.js 